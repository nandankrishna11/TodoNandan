class ProfileManager {
    constructor() {
        // Initialize storage first
        if (!window.storage) {
            window.storage = new Storage();
        }

        // Initialize if DOM is ready
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            this.init();
        } else {
            document.addEventListener('DOMContentLoaded', () => this.init());
        }
    }

    init() {
        this.cacheElements();
        this.loadUserProfile();
        this.updateTaskStatistics();
        this.setupEventListeners();
        
        // Initial animation of stat cards
        this.animateStatCardsIn();
    }

    cacheElements() {
        // Statistics elements
        this.elements = {
            totalTasksCount: document.getElementById('totalTasksCount'),
            completedTasksCount: document.getElementById('completedTasksCount'),
            pendingTasksCount: document.getElementById('pendingTasksCount'),
            completionRate: document.getElementById('completionRate'),
            progressPercentage: document.getElementById('progressPercentage'),
            progressFill: document.querySelector('.progress-fill'),
            
            // Profile elements
            userName: document.getElementById('userName'),
            userEmail: document.getElementById('userEmail'),
            userPhone: document.getElementById('userPhone'),
            userPhoto: document.getElementById('userPhoto'),
            
            // Edit modal elements
            editProfileModal: document.getElementById('editProfileModal'),
            editName: document.getElementById('editName'),
            editEmail: document.getElementById('editEmail'),
            editPhone: document.getElementById('editPhone'),
            editUserPhoto: document.getElementById('editUserPhoto'),
            photoInput: document.getElementById('photoInput'),
            editPhotoInput: document.getElementById('editPhotoInput'),
            
            // Forms
            profileForm: document.getElementById('profileForm')
        };
    }

    setupEventListeners() {
        // Photo upload handling
        if (this.elements.photoInput) {
            this.elements.photoInput.addEventListener('change', (e) => this.handlePhotoUpload(e));
        }
        if (this.elements.editPhotoInput) {
            this.elements.editPhotoInput.addEventListener('change', (e) => this.handlePhotoUpload(e, true));
        }

        // Form submission
        if (this.elements.profileForm) {
            this.elements.profileForm.addEventListener('submit', (e) => this.saveProfile(e));
        }

        // Listen for task status changes and stats updates
        window.addEventListener('taskStatusChanged', (event) => {
            console.log('Task status changed:', event.detail);
            this.updateTaskStatistics(event.detail.stats);
            this.animateStatCard(event.detail.completed);
        });

        window.addEventListener('statsUpdated', (event) => {
            console.log('Stats updated:', event.detail);
            this.updateTaskStatistics(event.detail.stats);
        });

        // Make functions globally available for onclick handlers
        window.openEditModal = () => this.openEditModal();
        window.closeEditModal = () => this.closeEditModal();
        window.saveProfile = (e) => this.saveProfile(e);
    }

    updateTaskStatistics(stats = null) {
        try {
            console.log('Updating task statistics with:', stats);
            
            // Get task statistics from storage if not provided
            if (!stats) {
                stats = window.storage ? window.storage.getTaskStats() : { total: 0, completed: 0, pending: 0 };
            }
            
            console.log('Final stats to display:', stats);
            
            // Calculate completion rate
            const completionRate = stats.total > 0 
                ? Math.round((stats.completed / stats.total) * 100) 
                : 0;
            
            // Update statistics display with animation
            this.animateNumberChange(this.elements.totalTasksCount, stats.total || 0);
            this.animateNumberChange(this.elements.completedTasksCount, stats.completed || 0);
            this.animateNumberChange(this.elements.pendingTasksCount, stats.pending || 0);
            
            if (this.elements.completionRate) {
                this.elements.completionRate.textContent = `${completionRate}%`;
            }
            if (this.elements.progressPercentage) {
                this.elements.progressPercentage.textContent = `${completionRate}%`;
            }
            if (this.elements.progressFill) {
                this.elements.progressFill.style.width = `${completionRate}%`;
            }

        } catch (error) {
            console.error('Error updating task statistics:', error);
            this.setDefaultStats();
        }
    }

    animateStatCardsIn() {
        const cards = document.querySelectorAll('.stat-card');
        cards.forEach((card, index) => {
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }

    animateStatCard(isCompleted) {
        const targetCard = isCompleted ? 
            this.elements.completedTasksCount.closest('.stat-card') : 
            this.elements.pendingTasksCount.closest('.stat-card');
        
        if (targetCard) {
            targetCard.classList.remove('pulse-animation');
            // Trigger reflow
            void targetCard.offsetWidth;
            targetCard.classList.add('pulse-animation');
        }
    }

    animateNumberChange(element, newValue) {
        if (!element) return;
        
        const currentValue = parseInt(element.textContent) || 0;
        const diff = newValue - currentValue;
        
        if (diff === 0) return;
        
        const duration = 1000; // 1 second
        const steps = 60;
        const stepValue = diff / steps;
        let currentStep = 0;
        
        const animate = () => {
            currentStep++;
            const current = currentValue + (stepValue * currentStep);
            element.textContent = Math.round(current);
            
            if (currentStep < steps) {
                requestAnimationFrame(animate);
            } else {
                element.textContent = newValue;
            }
        };
        
        requestAnimationFrame(animate);
    }

    setDefaultStats() {
        const defaultStats = { total: 0, completed: 0, pending: 0, completionRate: '0%' };
        
        if (this.elements.totalTasksCount) {
            this.elements.totalTasksCount.textContent = defaultStats.total;
        }
        if (this.elements.completedTasksCount) {
            this.elements.completedTasksCount.textContent = defaultStats.completed;
        }
        if (this.elements.pendingTasksCount) {
            this.elements.pendingTasksCount.textContent = defaultStats.pending;
        }
        if (this.elements.completionRate) {
            this.elements.completionRate.textContent = defaultStats.completionRate;
        }
        if (this.elements.progressPercentage) {
            this.elements.progressPercentage.textContent = defaultStats.completionRate;
        }
        if (this.elements.progressFill) {
            this.elements.progressFill.style.width = defaultStats.completionRate;
        }
    }

    loadUserProfile() {
        try {
            // Load profile data from localStorage
            const profile = localStorage.getItem('userProfile');
            if (profile) {
                const data = JSON.parse(profile);
                
                // Update profile display
                if (this.elements.userName) {
                    this.elements.userName.textContent = data.name || 'John Doe';
                }
                if (this.elements.userEmail) {
                    this.elements.userEmail.textContent = data.email || 'john@example.com';
                }
                if (this.elements.userPhone) {
                    this.elements.userPhone.textContent = data.phone || '+1 234 567 8900';
                }
                if (this.elements.userPhoto && data.photo) {
                    this.elements.userPhoto.src = data.photo;
                }
            }
        } catch (error) {
            console.error('Error loading user profile:', error);
        }
    }

    handlePhotoUpload(event, isEdit = false) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const photoUrl = e.target.result;
                if (isEdit && this.elements.editUserPhoto) {
                    this.elements.editUserPhoto.src = photoUrl;
                } else if (this.elements.userPhoto) {
                    this.elements.userPhoto.src = photoUrl;
                }
            };
            reader.readAsDataURL(file);
        }
    }

    openEditModal() {
        if (this.elements.editProfileModal) {
            this.elements.editProfileModal.classList.add('active');
            
            // Populate form with current values
            if (this.elements.editName) {
                this.elements.editName.value = this.elements.userName.textContent;
            }
            if (this.elements.editEmail) {
                this.elements.editEmail.value = this.elements.userEmail.textContent;
            }
            if (this.elements.editPhone) {
                this.elements.editPhone.value = this.elements.userPhone.textContent;
            }
            if (this.elements.editUserPhoto) {
                this.elements.editUserPhoto.src = this.elements.userPhoto.src;
            }
        }
    }

    closeEditModal() {
        if (this.elements.editProfileModal) {
            this.elements.editProfileModal.classList.remove('active');
        }
    }

    saveProfile(event) {
        event.preventDefault();
        
        try {
            const profileData = {
                name: this.elements.editName.value,
                email: this.elements.editEmail.value,
                phone: this.elements.editPhone.value,
                photo: this.elements.editUserPhoto.src
            };
            
            // Save to localStorage
            localStorage.setItem('userProfile', JSON.stringify(profileData));
            
            // Update display
            this.elements.userName.textContent = profileData.name;
            this.elements.userEmail.textContent = profileData.email;
            this.elements.userPhone.textContent = profileData.phone;
            this.elements.userPhoto.src = profileData.photo;
            
            // Close modal
            this.closeEditModal();
            
            // Show success message
            this.showToast('Profile updated successfully', 'success');
            
        } catch (error) {
            console.error('Error saving profile:', error);
            this.showToast('Error saving profile', 'error');
        }
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas ${this.getToastIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 100);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    getToastIcon(type) {
        switch (type) {
            case 'success': return 'fa-check-circle';
            case 'error': return 'fa-times-circle';
            case 'warning': return 'fa-exclamation-circle';
            default: return 'fa-info-circle';
        }
    }
}

// Initialize profile manager
const profileManager = new ProfileManager(); 