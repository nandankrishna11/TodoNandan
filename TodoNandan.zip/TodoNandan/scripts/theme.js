// Simple Theme Manager
const ThemeManager = {
    init() {
        // Get saved theme or default to light
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.applyTheme(savedTheme);
        
        // Setup listeners if on settings page
        if (document.querySelector('.theme-options')) {
            this.setupListeners();
        }
    },

    applyTheme(theme) {
        // Save theme
        localStorage.setItem('theme', theme);
        
        // Apply theme to document
        if (theme === 'system') {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
        } else {
            document.documentElement.setAttribute('data-theme', theme);
        }
        
        // Update radio buttons if on settings page
        const activeRadio = document.querySelector(`input[name="theme"][value="${theme}"]`);
        if (activeRadio) {
            activeRadio.checked = true;
            
            // Update theme option styling
            document.querySelectorAll('.theme-option').forEach(option => {
                option.classList.remove('active');
            });
            activeRadio.closest('.theme-option').classList.add('active');
        }
    },

    setupListeners() {
        // Theme option clicks
        document.querySelectorAll('.theme-option').forEach(option => {
            option.addEventListener('click', () => {
                const theme = option.dataset.theme;
                this.applyTheme(theme);
                Utils.showToast(`Theme changed to ${theme}`, 'success');
            });
        });

        // Listen for system theme changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (localStorage.getItem('theme') === 'system') {
                this.applyTheme('system');
            }
        });
    }
};

// Initialize theme manager
document.addEventListener('DOMContentLoaded', () => {
    ThemeManager.init();
}); 