/**
 * Utility Functions for TaskFlow Application
 * Contains helper functions for date formatting, validation, and DOM manipulation
 */

class Utils {
    /**
     * Formats a date string into a readable format
     * @param {string} dateString - ISO date string
     * @param {boolean} includeTime - Whether to include time in the format
     * @returns {string} Formatted date string
     */
    static formatDate(dateString, includeTime = false) {
        if (!dateString) return '';
        
        try {
            const date = new Date(dateString);
            const now = new Date();
            const diffInMs = date.getTime() - now.getTime();
            const diffInDays = Math.ceil(diffInMs / (1000 * 60 * 60 * 24));
            
            // Format options
            const options = {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            };
            
            if (includeTime) {
                options.hour = '2-digit';
                options.minute = '2-digit';
            }
            
            const formatted = date.toLocaleDateString('en-US', options);
            
            // Add relative time indicators
            if (diffInDays === 0) {
                return includeTime ? 
                    `Today at ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}` : 
                    'Today';
            } else if (diffInDays === 1) {
                return includeTime ? 
                    `Tomorrow at ${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}` : 
                    'Tomorrow';
            } else if (diffInDays === -1) {
                return 'Yesterday';
            } else if (diffInDays > 1 && diffInDays <= 7) {
                return `In ${diffInDays} days`;
            } else if (diffInDays < -1 && diffInDays >= -7) {
                return `${Math.abs(diffInDays)} days ago`;
            }
            
            return formatted;
        } catch (error) {
            console.error('Error formatting date:', error);
            return dateString;
        }
    }
    
    /**
     * Determines if a due date is overdue or due soon
     * @param {string} dueDateString - ISO date string
     * @returns {string} 'overdue', 'due-soon', or 'normal'
     */
    static getDueDateStatus(dueDateString) {
        if (!dueDateString) return 'normal';
        
        try {
            const dueDate = new Date(dueDateString);
            const now = new Date();
            const diffInMs = dueDate.getTime() - now.getTime();
            const diffInHours = diffInMs / (1000 * 60 * 60);
            
            if (diffInMs < 0) {
                return 'overdue';
            } else if (diffInHours <= 24) {
                return 'due-soon';
            }
            
            return 'normal';
        } catch (error) {
            console.error('Error determining due date status:', error);
            return 'normal';
        }
    }
    
    /**
     * Validates task form data
     * @param {Object} taskData - Task data object
     * @returns {Object} Validation result with isValid boolean and errors object
     */
    static validateTask(taskData) {
        const errors = {};
        let isValid = true;
        
        // Title validation
        if (!taskData.title || taskData.title.trim().length === 0) {
            errors.title = 'Title is required';
            isValid = false;
        } else if (taskData.title.trim().length > 100) {
            errors.title = 'Title must be less than 100 characters';
            isValid = false;
        }
        
        // Category validation
        if (!taskData.category) {
            errors.category = 'Category is required';
            isValid = false;
        }
        
        // Priority validation
        if (!taskData.priority) {
            errors.priority = 'Priority is required';
            isValid = false;
        }
        
        // Due date validation (if provided)
        if (taskData.dueDate) {
            const dueDate = new Date(taskData.dueDate);
            if (isNaN(dueDate.getTime())) {
                errors.dueDate = 'Please enter a valid due date';
                isValid = false;
            }
        }
        
        // Description validation (optional but with limit)
        if (taskData.description && taskData.description.length > 500) {
            errors.description = 'Description must be less than 500 characters';
            isValid = false;
        }
        
        return {
            isValid,
            errors
        };
    }
    
    /**
     * Generates a unique ID for tasks
     * @returns {string} Unique ID string
     */
    static generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    
    /**
     * Debounces a function call
     * @param {Function} func - Function to debounce
     * @param {number} wait - Wait time in milliseconds
     * @returns {Function} Debounced function
     */
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    /**
     * Escapes HTML to prevent XSS attacks
     * @param {string} text - Text to escape
     * @returns {string} Escaped text
     */
    static escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
    /**
     * Capitalizes the first letter of a string
     * @param {string} str - String to capitalize
     * @returns {string} Capitalized string
     */
    static capitalize(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
    
    /**
     * Filters tasks based on search criteria
     * @param {Array} tasks - Array of task objects
     * @param {Object} filters - Filter criteria object
     * @returns {Array} Filtered tasks array
     */
    static filterTasks(tasks, filters) {
        return tasks.filter(task => {
            // Search filter
            if (filters.search && !task.title.toLowerCase().includes(filters.search.toLowerCase())) {
                return false;
            }
            
            // Category filter
            if (filters.category !== 'all' && task.category !== filters.category) {
                return false;
            }
            
            // Priority filter
            if (filters.priority !== 'all' && task.priority !== filters.priority) {
                return false;
            }
            
            // Status filter
            if (filters.status === 'completed' && !task.completed) {
                return false;
            }
            if (filters.status === 'pending' && task.completed) {
                return false;
            }
            
            return true;
        });
    }
    
    /**
     * Sorts tasks based on specified criteria
     * @param {Array} tasks - Array of task objects
     * @param {string} sortBy - Sort criteria ('title', 'dueDate', 'priority', 'created')
     * @param {string} sortOrder - Sort order ('asc' or 'desc')
     * @returns {Array} Sorted tasks array
     */
    static sortTasks(tasks, sortBy = 'created', sortOrder = 'desc') {
        const sortedTasks = [...tasks];
        
        sortedTasks.sort((a, b) => {
            let comparison = 0;
            
            switch (sortBy) {
                case 'title':
                    comparison = a.title.localeCompare(b.title);
                    break;
                case 'dueDate':
                    const dateA = a.dueDate ? new Date(a.dueDate) : new Date(0);
                    const dateB = b.dueDate ? new Date(b.dueDate) : new Date(0);
                    comparison = dateA - dateB;
                    break;
                case 'priority':
                    const priorityOrder = { high: 3, medium: 2, low: 1 };
                    comparison = priorityOrder[b.priority] - priorityOrder[a.priority];
                    break;
                case 'created':
                default:
                    comparison = new Date(b.createdAt) - new Date(a.createdAt);
            }
            
            return sortOrder === 'asc' ? comparison : -comparison;
        });
        
        return sortedTasks;
    }
    
    /**
     * Shows a toast notification
     * @param {string} message - Message to display
     * @param {string} type - Notification type ('success', 'error', 'info')
     * @param {number} duration - Duration in milliseconds
     */
    static showToast(message, type = 'info', duration = 3000) {
        // Remove existing toast if any
        const existingToast = document.querySelector('.toast');
        if (existingToast) {
            existingToast.remove();
        }
        
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas ${this.getToastIcon(type)}"></i>
                <span>${this.escapeHtml(message)}</span>
            </div>
        `;
        
        // Add toast styles
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${this.getToastColor(type)};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 10000;
            font-family: var(--font-family);
            font-size: 14px;
            transform: translateX(400px);
            transition: transform 0.3s ease;
        `;
        
        // Add to document
        document.body.appendChild(toast);
        
        // Animate in
        setTimeout(() => {
            toast.style.transform = 'translateX(0)';
        }, 10);
        
        // Remove after duration
        setTimeout(() => {
            toast.style.transform = 'translateX(400px)';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.remove();
                }
            }, 300);
        }, duration);
    }
    
    /**
     * Gets the appropriate icon for toast notifications
     * @param {string} type - Toast type
     * @returns {string} Font Awesome icon class
     */
    static getToastIcon(type) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        return icons[type] || icons.info;
    }
    
    /**
     * Gets the appropriate background color for toast notifications
     * @param {string} type - Toast type
     * @returns {string} CSS color value
     */
    static getToastColor(type) {
        const colors = {
            success: 'hsl(142, 71%, 45%)',
            error: 'hsl(0, 72%, 51%)',
            warning: 'hsl(38, 92%, 50%)',
            info: 'hsl(220, 84%, 58%)'
        };
        return colors[type] || colors.info;
    }
    
    /**
     * Animates an element with a specified animation
     * @param {HTMLElement} element - Element to animate
     * @param {string} animationClass - CSS animation class
     * @param {Function} callback - Callback function after animation
     */
    static animateElement(element, animationClass, callback) {
        element.classList.add(animationClass);
        
        const handleAnimationEnd = () => {
            element.classList.remove(animationClass);
            element.removeEventListener('animationend', handleAnimationEnd);
            if (callback) callback();
        };
        
        element.addEventListener('animationend', handleAnimationEnd);
    }
    
    /**
     * Gets category icon based on category type
     * @param {string} category - Category name
     * @returns {string} Font Awesome icon class
     */
    static getCategoryIcon(category) {
        const icons = {
            work: 'fa-briefcase',
            personal: 'fa-user',
            shopping: 'fa-shopping-cart',
            health: 'fa-heartbeat',
            education: 'fa-graduation-cap'
        };
        return icons[category] || 'fa-folder';
    }
    
    /**
     * Gets priority icon based on priority level
     * @param {string} priority - Priority level
     * @returns {string} Font Awesome icon class
     */
    static getPriorityIcon(priority) {
        const icons = {
            high: 'fa-exclamation-circle',
            medium: 'fa-dot-circle',
            low: 'fa-arrow-circle-down'
        };
        return icons[priority] || 'fa-circle';
    }
}

// Export for use in other modules
window.Utils = Utils;

// Theme Management - Move inside DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('themeToggle');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');

    // Function to set theme
    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        if (themeToggle) {
            // Update toggle button icon if it exists
            const icon = themeToggle.querySelector('i');
            if (icon) {
                icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
            }
        }
    }

    // Make setTheme globally available
    window.setTheme = setTheme;

    // Function to toggle theme
    function toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
    }

    // Initialize theme
    function initializeTheme() {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            setTheme(savedTheme);
        } else {
            // Use system preference as default
            setTheme(prefersDarkScheme.matches ? 'dark' : 'light');
        }
    }

    // Event Listeners
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
    
    prefersDarkScheme.addEventListener('change', (e) => {
        if (!localStorage.getItem('theme')) {
            setTheme(e.matches ? 'dark' : 'light');
        }
    });

    // Initialize theme when the page loads
    initializeTheme();
});
