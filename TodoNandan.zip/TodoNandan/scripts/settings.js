// Theme Management
class ThemeManager {
    constructor() {
        this.themeKey = 'taskflow_theme';
        this.defaultTheme = 'system';
        this.htmlElement = document.documentElement;
        this.mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        
        // Initialize theme
        this.currentTheme = localStorage.getItem(this.themeKey) || this.defaultTheme;
        this.initializeTheme();
        
        // Bind event listeners
        this.mediaQuery.addListener(this.handleSystemThemeChange.bind(this));
    }

    initializeTheme() {
        // Set radio button
        const radioButton = document.querySelector(`input[name="theme"][value="${this.currentTheme}"]`);
        if (radioButton) {
            radioButton.checked = true;
            const themeOption = radioButton.closest('.theme-option');
            if (themeOption) {
                themeOption.classList.add('active');
            }
        }

        // Apply theme
        this.applyTheme(this.currentTheme);
    }

    applyTheme(theme) {
        if (theme === 'system') {
            this.applySystemTheme();
        } else {
            this.htmlElement.setAttribute('data-theme', theme);
        }
        localStorage.setItem(this.themeKey, theme);
        this.currentTheme = theme;
    }

    applySystemTheme() {
        const theme = this.mediaQuery.matches ? 'dark' : 'light';
        this.htmlElement.setAttribute('data-theme', theme);
    }

    handleSystemThemeChange(e) {
        if (this.currentTheme === 'system') {
            this.applySystemTheme();
        }
    }

    getCurrentTheme() {
        return this.currentTheme;
    }
}

// Settings Manager
class SettingsManager {
    constructor() {
        this.settingsKey = 'taskflow_settings';
        this.defaultSettings = {
            taskReminders: true,
            dailySummary: false,
            saveHistory: true
        };
        this.settings = this.loadSettings();
        this.initializeSettings();
        this.setupEventListeners();
    }

    loadSettings() {
        const savedSettings = localStorage.getItem(this.settingsKey);
        return savedSettings ? JSON.parse(savedSettings) : { ...this.defaultSettings };
    }

    saveSettings() {
        localStorage.setItem(this.settingsKey, JSON.stringify(this.settings));
        Utils.showToast('Settings saved successfully', 'success');
    }

    initializeSettings() {
        // Initialize checkboxes
        Object.entries(this.settings).forEach(([key, value]) => {
            const checkbox = document.getElementById(key);
            if (checkbox) {
                checkbox.checked = value;
            }
        });

        // Initialize theme options
        const currentTheme = themeManager.getCurrentTheme();
        this.updateThemeUI(currentTheme);
    }

    updateThemeUI(theme) {
        // Remove active class from all options
        document.querySelectorAll('.theme-option').forEach(option => {
            option.classList.remove('active');
        });

        // Add active class to selected theme
        const selectedOption = document.querySelector(`.theme-option[data-theme="${theme}"]`);
        if (selectedOption) {
            selectedOption.classList.add('active');
            const radio = selectedOption.querySelector('input[type="radio"]');
            if (radio) {
                radio.checked = true;
            }
        }
    }

    setupEventListeners() {
        // Theme option clicks
        const themeOptions = document.querySelectorAll('.theme-option');
        themeOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                e.preventDefault();
                const theme = option.dataset.theme;
                
                // Update UI
                this.updateThemeUI(theme);
                
                // Apply theme
                themeManager.applyTheme(theme);
                Utils.showToast(`Theme changed to ${theme}`, 'success');
            });
        });

        // Setting toggles
        const toggleInputs = document.querySelectorAll('.setting-item input[type="checkbox"]');
        toggleInputs.forEach(input => {
            input.addEventListener('change', () => {
                this.updateSetting(input.id, input.checked);
            });
        });

        // Clear data button
        const clearDataBtn = document.getElementById('clearDataBtn');
        if (clearDataBtn) {
            clearDataBtn.addEventListener('click', () => {
                this.clearAllData();
            });
        }

        // Listen for theme changes from other sources
        window.addEventListener('themechange', (e) => {
            this.updateThemeUI(themeManager.getCurrentTheme());
        });
    }

    updateSetting(key, value) {
        this.settings[key] = value;
        this.saveSettings();
    }

    clearAllData() {
        if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
            // Clear all localStorage data except theme
            const currentTheme = localStorage.getItem('taskflow_theme');
            localStorage.clear();
            if (currentTheme) {
                localStorage.setItem('taskflow_theme', currentTheme);
            }
            
            // Reset settings to defaults
            this.settings = { ...this.defaultSettings };
            this.initializeSettings();
            
            Utils.showToast('All data has been cleared', 'info');
            
            // Slight delay before reload to show the toast
            setTimeout(() => window.location.reload(), 1500);
        }
    }
}

// Initialize Managers
const themeManager = new ThemeManager();
const settingsManager = new SettingsManager();

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Theme option clicks
    const themeOptions = document.querySelectorAll('.theme-option');
    themeOptions.forEach(option => {
        option.addEventListener('click', () => {
            // Update active state
            themeOptions.forEach(opt => opt.classList.remove('active'));
            option.classList.add('active');
            
            // Apply theme
            const theme = option.dataset.theme;
            themeManager.applyTheme(theme);
            Utils.showToast(`Theme changed to ${theme}`, 'success');
        });
    });

    // Setting toggles
    const toggleInputs = document.querySelectorAll('.setting-item input[type="checkbox"]');
    toggleInputs.forEach(input => {
        input.addEventListener('change', () => {
            settingsManager.updateSetting(input.id, input.checked);
        });
    });

    // Clear data button
    const clearDataBtn = document.getElementById('clearDataBtn');
    if (clearDataBtn) {
        clearDataBtn.addEventListener('click', () => {
            settingsManager.clearAllData();
        });
    }
}); 