/**
 * Local Storage Manager for TaskFlow Application
 * Handles all local storage operations for task persistence
 */

class Storage {
    constructor() {
        // Singleton pattern
        if (Storage.instance) {
            return Storage.instance;
        }
        Storage.instance = this;
        
        // Initialize storage
        this.tasks = this.loadTasks();
        this.settings = this.loadSettings();
    }

    /**
     * Load tasks from localStorage
     * @returns {Array} Array of tasks
     */
    loadTasks() {
        try {
            const tasks = localStorage.getItem('tasks');
            return tasks ? JSON.parse(tasks) : [];
        } catch (error) {
            console.error('Error loading tasks:', error);
            return [];
        }
    }

    /**
     * Save tasks to localStorage
     */
    saveTasks() {
        try {
            localStorage.setItem('tasks', JSON.stringify(this.tasks));
        } catch (error) {
            console.error('Error saving tasks:', error);
        }
    }

    /**
     * Load settings from localStorage
     * @returns {Object} Settings object
     */
    loadSettings() {
        try {
            const settings = localStorage.getItem('settings');
            return settings ? JSON.parse(settings) : {
                theme: 'light',
                sortBy: 'created',
                sortOrder: 'desc'
            };
        } catch (error) {
            console.error('Error loading settings:', error);
            return {
                theme: 'light',
                sortBy: 'created',
                sortOrder: 'desc'
            };
        }
    }

    /**
     * Save settings to localStorage
     */
    saveSettings() {
        try {
            localStorage.setItem('settings', JSON.stringify(this.settings));
        } catch (error) {
            console.error('Error saving settings:', error);
        }
    }

    /**
     * Get all tasks
     * @returns {Array} Array of tasks
     */
    getAllTasks() {
        return this.tasks;
    }

    /**
     * Get task by ID
     * @param {string} taskId - Task ID
     * @returns {Object|null} Task object or null if not found
     */
    getTask(taskId) {
        return this.tasks.find(task => task.id === taskId) || null;
    }

    /**
     * Add new task
     * @param {Object} taskData - Task data
     * @returns {Object|null} Created task or null if failed
     */
    addTask(taskData) {
        try {
            // Check for duplicate task
            const isDuplicate = this.tasks.some(task => 
                task.title === taskData.title &&
                task.description === taskData.description &&
                task.category === taskData.category &&
                task.priority === taskData.priority &&
                task.dueDate === taskData.dueDate
            );

            if (isDuplicate) {
                console.warn('Duplicate task detected');
                return null;
            }

            const task = {
                id: Utils.generateId(),
                title: taskData.title,
                description: taskData.description || '',
                category: taskData.category,
                priority: taskData.priority,
                dueDate: taskData.dueDate,
                completed: false,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };

            this.tasks.unshift(task);
            this.saveTasks();
            return task;
        } catch (error) {
            console.error('Error adding task:', error);
            return null;
        }
    }

    /**
     * Update existing task
     * @param {string} taskId - Task ID
     * @param {Object} taskData - Updated task data
     * @returns {Object|null} Updated task or null if failed
     */
    updateTask(taskId, taskData) {
        try {
            const taskIndex = this.tasks.findIndex(task => task.id === taskId);
            if (taskIndex === -1) return null;

            const updatedTask = {
                ...this.tasks[taskIndex],
                ...taskData,
                updatedAt: new Date().toISOString()
            };

            this.tasks[taskIndex] = updatedTask;
            this.saveTasks();
            return updatedTask;
        } catch (error) {
            console.error('Error updating task:', error);
            return null;
        }
    }

    /**
     * Delete task
     * @param {string} taskId - Task ID
     * @returns {boolean} Success status
     */
    deleteTask(taskId) {
        try {
            const taskIndex = this.tasks.findIndex(task => task.id === taskId);
            if (taskIndex === -1) return false;

            this.tasks.splice(taskIndex, 1);
            this.saveTasks();
            return true;
        } catch (error) {
            console.error('Error deleting task:', error);
            return false;
        }
    }

    /**
     * Toggle task completion status
     * @param {string} taskId - Task ID
     * @returns {Object|null} Updated task or null if failed
     */
    toggleTaskCompletion(taskId) {
        try {
            const task = this.getTask(taskId);
            if (!task) return null;

            task.completed = !task.completed;
            task.updatedAt = new Date().toISOString();
            this.saveTasks();
            return task;
        } catch (error) {
            console.error('Error toggling task completion:', error);
            return null;
        }
    }

    /**
     * Get task statistics
     * @returns {Object} Task statistics
     */
    getTaskStats() {
        const total = this.tasks.length;
        const completed = this.tasks.filter(task => task.completed).length;
        const pending = total - completed;

        return {
            total,
            completed,
            pending
        };
    }

    /**
     * Export all data
     * @returns {Object} Exported data
     */
    exportData() {
        return {
            tasks: this.tasks,
            settings: this.settings,
            exportedAt: new Date().toISOString()
        };
    }

    /**
     * Import data
     * @param {Object} data - Data to import
     * @returns {boolean} Success status
     */
    importData(data) {
        try {
            if (!data.tasks || !Array.isArray(data.tasks)) {
                throw new Error('Invalid tasks data');
            }

            this.tasks = data.tasks;
            if (data.settings) {
                this.settings = data.settings;
                this.saveSettings();
            }

            this.saveTasks();
            return true;
        } catch (error) {
            console.error('Error importing data:', error);
            return false;
        }
    }

    /**
     * Update settings
     * @param {Object} newSettings - New settings
     * @returns {Object} Updated settings
     */
    updateSettings(newSettings) {
        try {
            this.settings = {
                ...this.settings,
                ...newSettings
            };
            this.saveSettings();
            return this.settings;
        } catch (error) {
            console.error('Error updating settings:', error);
            return null;
        }
    }

    /**
     * Get settings
     * @returns {Object} Settings object
     */
    getSettings() {
        return this.settings;
    }
}

// Initialize storage and make it globally available
window.storage = new Storage();
