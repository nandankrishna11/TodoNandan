/**
 * TaskFlow - Main Application Controller
 * Handles all UI interactions, task management, and application state
 */

class TaskFlowApp {
    constructor() {
        // Initialize the application immediately if DOM is ready
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            this.init();
        } else {
            // Wait for DOM to be ready before initializing
            document.addEventListener('DOMContentLoaded', () => this.init());
        }
    }
    
    /**
     * Initialize the application
     */
    init() {
        // Application state
        this.currentFilters = {
            search: '',
            category: 'all',
            priority: 'all',
            status: 'all'
        };
        
        this.editingTaskId = null;
        this.sortBy = 'created';
        this.sortOrder = 'desc';
        
        // DOM elements (will be initialized in cacheElements)
        this.elements = {};
        
        // Initialize the application
        this.initialize();
    }
    
    /**
     * Initialize application after DOM is ready
     */
    initialize() {
        try {
            // Cache DOM elements
            this.cacheElements();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Load user settings
            this.loadSettings();
            
            // Initial render
            this.renderTasks();
            this.updateStats();
            
            // Show welcome message for new users
            this.showWelcomeMessage();
            
            console.log('TaskFlow initialized successfully');
            
        } catch (error) {
            console.error('Error initializing application:', error);
            Utils.showToast('Error initializing application', 'error');
        }
    }
    
    /**
     * Cache frequently used DOM elements
     */
    cacheElements() {
        this.elements = {
            // Header elements
            totalTasks: document.getElementById('totalTasks'),
            completedTasks: document.getElementById('completedTasks'),
            pendingTasks: document.getElementById('pendingTasks'),
            
            // Control panel elements
            searchInput: document.getElementById('searchInput'),
            categoryFilter: document.getElementById('categoryFilter'),
            priorityFilter: document.getElementById('priorityFilter'),
            statusFilter: document.getElementById('statusFilter'),
            clearFiltersBtn: document.getElementById('clearFiltersBtn'),
            
            // Tasks section
            tasksContainer: document.getElementById('tasksContainer'),
            emptyState: document.getElementById('emptyState'),
            emptyStateBtn: document.getElementById('emptyStateBtn'),
            
            // FAB elements
            fabButton: document.getElementById('fabButton'),
            fabMenu: document.getElementById('fabMenu'),
            fabAddTaskBtn: document.getElementById('fabAddTaskBtn'),
            
            // Modal elements
            taskModal: document.getElementById('taskModal'),
            modalTitle: document.getElementById('modalTitle'),
            closeModalBtn: document.getElementById('closeModalBtn'),
            taskForm: document.getElementById('taskForm'),
            cancelBtn: document.getElementById('cancelBtn'),
            saveTaskBtn: document.getElementById('saveTaskBtn'),
            
            // Form elements
            taskTitle: document.getElementById('taskTitle'),
            taskDescription: document.getElementById('taskDescription'),
            taskCategory: document.getElementById('taskCategory'),
            taskPriority: document.getElementById('taskPriority'),
            taskDueDate: document.getElementById('taskDueDate'),
            
            // Error elements
            titleError: document.getElementById('titleError'),
            categoryError: document.getElementById('categoryError'),
            priorityError: document.getElementById('priorityError'),
            
            // Confirmation modal
            confirmModal: document.getElementById('confirmModal'),
            confirmMessage: document.getElementById('confirmMessage'),
            confirmCancelBtn: document.getElementById('confirmCancelBtn'),
            confirmActionBtn: document.getElementById('confirmActionBtn')
        };
    }
    
    /**
     * Set up event listeners
     */
    setupEventListeners() {
        // Empty state button
        if (this.elements.emptyStateBtn) {
            this.elements.emptyStateBtn.addEventListener('click', () => this.openTaskModal());
        }
        
        // FAB buttons
        if (this.elements.fabButton) {
            this.elements.fabButton.addEventListener('click', () => {
                this.elements.fabMenu.classList.toggle('active');
            });
        }
        
        if (this.elements.fabAddTaskBtn) {
            this.elements.fabAddTaskBtn.addEventListener('click', () => {
                this.elements.fabMenu.classList.remove('active');
                this.openTaskModal();
            });
        }
        
        // Close FAB menu when clicking outside
        document.addEventListener('click', (e) => {
            if (this.elements.fabMenu && 
                this.elements.fabButton && 
                !this.elements.fabButton.contains(e.target) && 
                !this.elements.fabMenu.contains(e.target)) {
                this.elements.fabMenu.classList.remove('active');
            }
        });
        
        // Search and filter events
        if (this.elements.searchInput) {
            this.elements.searchInput.addEventListener('input', 
                Utils.debounce((e) => this.handleSearch(e.target.value), 300)
            );
        }
        
        if (this.elements.categoryFilter) {
            this.elements.categoryFilter.addEventListener('change', (e) => 
                this.handleFilterChange('category', e.target.value)
            );
        }
        
        if (this.elements.priorityFilter) {
            this.elements.priorityFilter.addEventListener('change', (e) => 
                this.handleFilterChange('priority', e.target.value)
            );
        }
        
        if (this.elements.statusFilter) {
            this.elements.statusFilter.addEventListener('change', (e) => 
                this.handleFilterChange('status', e.target.value)
            );
        }
        
        if (this.elements.clearFiltersBtn) {
            this.elements.clearFiltersBtn.addEventListener('click', () => this.clearFilters());
        }
        
        // Modal events
        if (this.elements.closeModalBtn) {
            this.elements.closeModalBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleModalClose();
            });
        }
        
        if (this.elements.cancelBtn) {
            this.elements.cancelBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleModalClose();
            });
        }
        
        if (this.elements.taskModal) {
            this.elements.taskModal.addEventListener('click', (e) => {
                if (e.target === this.elements.taskModal) {
                    this.handleModalClose();
                }
            });
        }
        
        // Form events
        if (this.elements.taskForm) {
            this.elements.taskForm.addEventListener('submit', (e) => this.handleTaskSubmit(e));
        }
        
        // Confirmation modal events
        if (this.elements.confirmCancelBtn) {
            this.elements.confirmCancelBtn.addEventListener('click', () => this.closeConfirmModal());
        }
        
        if (this.elements.confirmModal) {
            this.elements.confirmModal.addEventListener('click', (e) => {
                if (e.target === this.elements.confirmModal) {
                    this.closeConfirmModal();
                }
            });
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
        
        // Handle browser back/forward
        window.addEventListener('popstate', () => this.handlePopState());
    }
    
    /**
     * Load user settings from storage
     */
    loadSettings() {
        try {
            const settings = window.storage.getSettings();
            if (settings) {
                this.sortBy = settings.sortBy || 'created';
                this.sortOrder = settings.sortOrder || 'desc';
            }
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }
    
    /**
     * Show welcome message for new users
     */
    showWelcomeMessage() {
        const tasks = window.storage.getAllTasks();
        if (tasks.length === 0) {
            setTimeout(() => {
                Utils.showToast('Welcome to TaskFlow! Create your first task to get started.', 'info', 5000);
            }, 1000);
        }
    }
    
    /**
     * Handle keyboard shortcuts
     * @param {KeyboardEvent} e - Keyboard event
     */
    handleKeyboardShortcuts(e) {
        // Ctrl/Cmd + N: New task
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            this.openTaskModal();
        }
        
        // Escape: Close modals
        if (e.key === 'Escape') {
            if (this.elements.taskModal.classList.contains('active')) {
                this.closeTaskModal();
            } else if (this.elements.confirmModal.classList.contains('active')) {
                this.closeConfirmModal();
            }
        }
        
        // Ctrl/Cmd + F: Focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
            e.preventDefault();
            this.elements.searchInput.focus();
        }
    }
    
    /**
     * Handle browser back/forward navigation
     */
    handlePopState() {
        // Close any open modals
        this.closeTaskModal();
        this.closeConfirmModal();
    }
    
    /**
     * Handle search input
     * @param {string} searchTerm - Search term
     */
    handleSearch(searchTerm) {
        this.currentFilters.search = searchTerm.trim();
        this.renderTasks();
    }
    
    /**
     * Handle filter changes
     * @param {string} filterType - Type of filter
     * @param {string} value - Filter value
     */
    handleFilterChange(filterType, value) {
        this.currentFilters[filterType] = value;
        this.renderTasks();
    }
    
    /**
     * Clear all filters
     */
    clearFilters() {
        this.currentFilters = {
            search: '',
            category: 'all',
            priority: 'all',
            status: 'all'
        };
        
        // Reset form values
        this.elements.searchInput.value = '';
        this.elements.categoryFilter.value = 'all';
        this.elements.priorityFilter.value = 'all';
        this.elements.statusFilter.value = 'all';
        
        this.renderTasks();
        Utils.showToast('Filters cleared', 'info');
    }
    
    /**
     * Open task modal for creating/editing task
     * @param {string} taskId - Task ID for editing (optional)
     */
    openTaskModal(taskId = null) {
        try {
            // Reset form and clear errors
            this.resetTaskForm();
            this.clearFormErrors();
            
            // Set modal title and editing state
            this.editingTaskId = taskId;
            this.elements.modalTitle.textContent = taskId ? 'Edit Task' : 'Add New Task';
            
            // If editing, populate form with task data
            if (taskId) {
                const task = window.storage.getTask(taskId);
                if (task) {
                    this.populateTaskForm(task);
                }
            }
            
            // Show modal
            this.elements.taskModal.classList.add('active');
            this.elements.taskTitle.focus();
            
            // Ensure form submission is properly bound
            this.elements.taskForm.onsubmit = (e) => this.handleTaskSubmit(e);
            
        } catch (error) {
            console.error('Error opening task modal:', error);
            Utils.showToast('Error opening task form. Please try again.', 'error');
        }
    }
    
    /**
     * Handle modal close with unsaved changes check
     */
    handleModalClose() {
        const hasUnsavedChanges = this.checkUnsavedChanges();
        
        if (hasUnsavedChanges) {
            this.showCloseConfirmation();
        } else {
            this.closeTaskModal();
        }
    }
    
    /**
     * Check if there are unsaved changes in the form
     * @returns {boolean} True if there are unsaved changes
     */
    checkUnsavedChanges() {
        const formData = {
            title: this.elements.taskTitle.value.trim(),
            description: this.elements.taskDescription.value.trim(),
            category: this.elements.taskCategory.value,
            priority: this.elements.taskPriority.value,
            dueDate: this.elements.taskDueDate.value
        };

        // If editing, compare with original task
        if (this.editingTaskId) {
            const originalTask = window.storage.getTask(this.editingTaskId);
            return formData.title !== originalTask.title ||
                   formData.description !== originalTask.description ||
                   formData.category !== originalTask.category ||
                   formData.priority !== originalTask.priority ||
                   formData.dueDate !== originalTask.dueDate;
        }

        // If creating new task, check if any field is filled
        return formData.title !== '' ||
               formData.description !== '' ||
               formData.category !== '' ||
               formData.priority !== '' ||
               formData.dueDate !== '';
    }
    
    /**
     * Show confirmation dialog for closing with unsaved changes
     */
    showCloseConfirmation() {
        this.elements.confirmMessage.textContent = 'You have unsaved changes. Are you sure you want to close?';
        this.elements.confirmActionBtn.textContent = 'Close without saving';
        this.elements.confirmActionBtn.onclick = () => {
            this.closeTaskModal();
            this.closeConfirmModal();
        };
        this.elements.confirmModal.classList.add('active');
    }
    
    /**
     * Close task modal
     */
    closeTaskModal() {
        // Remove active class with fade-out animation
        this.elements.taskModal.classList.add('fade-out');
        
        // Wait for animation to complete
        setTimeout(() => {
            this.elements.taskModal.classList.remove('active', 'fade-out');
            this.editingTaskId = null;
            this.resetTaskForm();
            
            // Remove form submission handler
            this.elements.taskForm.onsubmit = null;
        }, 300); // Match this with your CSS animation duration
    }
    
    /**
     * Populate task form with existing task data
     * @param {Object} task - Task object
     */
    populateTaskForm(task) {
        this.elements.taskTitle.value = task.title || '';
        this.elements.taskDescription.value = task.description || '';
        this.elements.taskCategory.value = task.category || '';
        this.elements.taskPriority.value = task.priority || '';
        
        if (task.dueDate) {
            // Convert ISO string to datetime-local format
            const date = new Date(task.dueDate);
            const localDateTime = new Date(date.getTime() - date.getTimezoneOffset() * 60000)
                .toISOString().slice(0, 16);
            this.elements.taskDueDate.value = localDateTime;
        } else {
            this.elements.taskDueDate.value = '';
        }
    }
    
    /**
     * Reset task form to initial state
     */
    resetTaskForm() {
        this.elements.taskForm.reset();
        this.clearFormErrors();
        
        // Reset any custom styles
        this.elements.taskTitle.style.borderColor = '';
        this.elements.taskCategory.style.borderColor = '';
        this.elements.taskPriority.style.borderColor = '';
    }
    
    /**
     * Clear form error messages
     */
    clearFormErrors() {
        this.elements.titleError.textContent = '';
        this.elements.categoryError.textContent = '';
        this.elements.priorityError.textContent = '';
    }
    
    /**
     * Handle task form submission
     * @param {Event} e - Form submission event
     */
    handleTaskSubmit(e) {
        e.preventDefault();
        
        try {
            // Clear previous errors
            this.clearFormErrors();
            
            // Get form data
            const formData = {
                title: this.elements.taskTitle.value.trim(),
                description: this.elements.taskDescription.value.trim(),
                category: this.elements.taskCategory.value,
                priority: this.elements.taskPriority.value,
                dueDate: this.elements.taskDueDate.value || null
            };
            
            // Validate form data
            const validation = Utils.validateTask(formData);
            if (!validation.isValid) {
                this.displayFormErrors(validation.errors);
                return;
            }
            
            // Create or update task
            let task;
            if (this.editingTaskId) {
                // Update existing task
                task = window.storage.updateTask(this.editingTaskId, formData);
                if (task) {
                    Utils.showToast('Task updated successfully', 'success');
                }
            } else {
                // Create new task
                task = window.storage.addTask(formData);
                if (task) {
                    Utils.showToast('Task created successfully', 'success');
                }
            }
            
            if (task) {
                // Close modal and refresh tasks
                this.closeTaskModal();
                this.renderTasks();
                this.updateStats();
                
                // Hide empty state if it was showing
                if (this.elements.emptyState) {
                    this.elements.emptyState.style.display = 'none';
                }
            } else {
                Utils.showToast('Error saving task. Please try again.', 'error');
            }
            
        } catch (error) {
            console.error('Error handling task submission:', error);
            Utils.showToast('Error saving task. Please try again.', 'error');
        }
    }
    
    /**
     * Display form validation errors
     * @param {Object} errors - Validation errors object
     */
    displayFormErrors(errors) {
        if (errors.title) {
            this.elements.titleError.textContent = errors.title;
        }
        if (errors.category) {
            this.elements.categoryError.textContent = errors.category;
        }
        if (errors.priority) {
            this.elements.priorityError.textContent = errors.priority;
        }
    }
    
    /**
     * Render all tasks based on current filters
     */
    renderTasks() {
        try {
            // Get all tasks
            let tasks = window.storage.getAllTasks();
            
            // Apply filters
            tasks = Utils.filterTasks(tasks, this.currentFilters);
            
            // Sort tasks
            tasks = Utils.sortTasks(tasks, this.sortBy, this.sortOrder);
            
            // Clear container
            this.elements.tasksContainer.innerHTML = '';
            
            // Show empty state if no tasks
            if (tasks.length === 0) {
                this.showEmptyState();
                return;
            }
            
            // Render each task
            tasks.forEach(task => {
                const taskElement = this.createTaskElement(task);
                this.elements.tasksContainer.appendChild(taskElement);
            });
            
            // Animate tasks in
            this.animateTasksIn();
            
        } catch (error) {
            console.error('Error rendering tasks:', error);
            Utils.showToast('Error loading tasks', 'error');
        }
    }
    
    /**
     * Show empty state
     */
    showEmptyState() {
        const hasActiveFilters = this.currentFilters.search || 
            this.currentFilters.category !== 'all' ||
            this.currentFilters.priority !== 'all' ||
            this.currentFilters.status !== 'all';
        
        let emptyStateHTML = '';
        
        if (hasActiveFilters) {
            emptyStateHTML = `
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <h3>No tasks match your filters</h3>
                    <p>Try adjusting your search criteria or clearing filters</p>
                    <button class="btn btn-secondary" onclick="app.clearFilters()">
                        <i class="fas fa-times"></i>
                        Clear Filters
                    </button>
                </div>
            `;
        } else {
            emptyStateHTML = `
                <div class="empty-state">
                    <i class="fas fa-clipboard-list"></i>
                    <h3>No tasks found</h3>
                    <p>Create your first task to get started with TaskFlow</p>
                    <button class="btn btn-primary" onclick="app.openTaskModal()">
                        <i class="fas fa-plus"></i>
                        Create First Task
                    </button>
                </div>
            `;
        }
        
        this.elements.tasksContainer.innerHTML = emptyStateHTML;
    }
    
    /**
     * Create a task element
     * @param {Object} task - Task object
     * @returns {HTMLElement} Task element
     */
    createTaskElement(task) {
        const taskDiv = document.createElement('div');
        taskDiv.className = `task-card ${task.completed ? 'completed' : ''}`;
        taskDiv.setAttribute('data-task-id', task.id);
        
        const dueDateStatus = Utils.getDueDateStatus(task.dueDate);
        const dueDateClass = dueDateStatus !== 'normal' ? dueDateStatus : '';
        
        taskDiv.innerHTML = `
            <div class="task-header">
                <div class="task-info">
                    <h3 class="task-title">${Utils.escapeHtml(task.title)}</h3>
                    ${task.description ? `<p class="task-description">${Utils.escapeHtml(task.description)}</p>` : ''}
                </div>
                <div class="task-actions">
                    <div class="task-checkbox ${task.completed ? 'checked' : ''}" 
                         onclick="app.toggleTaskCompletion('${task.id}')">
                    </div>
                    <button class="action-btn" onclick="app.openTaskModal('${task.id}')" 
                            title="Edit task">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete-btn" onclick="app.confirmDeleteTask('${task.id}')" 
                            title="Delete task">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <div class="task-meta">
                <span class="task-badge category-${task.category}">
                    <i class="fas ${Utils.getCategoryIcon(task.category)}"></i>
                    ${Utils.capitalize(task.category)}
                </span>
                <span class="task-badge priority-${task.priority}">
                    <i class="fas ${Utils.getPriorityIcon(task.priority)}"></i>
                    ${Utils.capitalize(task.priority)} Priority
                </span>
                ${task.dueDate ? `
                    <span class="task-due-date ${dueDateClass}">
                        <i class="fas fa-calendar-alt"></i>
                        ${Utils.formatDate(task.dueDate, true)}
                    </span>
                ` : ''}
            </div>
        `;
        
        return taskDiv;
    }
    
    /**
     * Animate tasks in
     */
    animateTasksIn() {
        const taskElements = this.elements.tasksContainer.querySelectorAll('.task-card');
        taskElements.forEach((element, index) => {
            setTimeout(() => {
                element.classList.add('slide-in');
            }, index * 50);
        });
    }
    
    /**
     * Toggle task completion status
     * @param {string} taskId - Task ID
     */
    toggleTaskCompletion(taskId) {
        try {
            const task = window.storage.toggleTaskCompletion(taskId);
            if (task) {
                this.renderTasks();
                this.updateStats();
                
                // Dispatch custom event for task status change
                const taskStatusEvent = new CustomEvent('taskStatusChanged', {
                    detail: {
                        taskId: taskId,
                        completed: task.completed,
                        stats: window.storage.getTaskStats()
                    }
                });
                window.dispatchEvent(taskStatusEvent);
                
                // Show success message
                Utils.showToast(task.completed ? 'Task completed!' : 'Task reopened!', 'success');
            }
        } catch (error) {
            console.error('Error toggling task completion:', error);
            Utils.showToast('Error updating task status', 'error');
        }
    }
    
    /**
     * Show confirmation dialog for task deletion
     * @param {string} taskId - Task ID to delete
     */
    confirmDeleteTask(taskId) {
        const task = window.storage.getTask(taskId);
        if (!task) {
            Utils.showToast('Task not found', 'error');
            return;
        }
        
        this.elements.confirmMessage.textContent = 
            `Are you sure you want to delete "${task.title}"? This action cannot be undone.`;
        
        this.elements.confirmActionBtn.onclick = () => {
            this.deleteTask(taskId);
            this.closeConfirmModal();
        };
        
        this.elements.confirmModal.classList.add('active');
    }
    
    /**
     * Delete a task
     * @param {string} taskId - Task ID to delete
     */
    deleteTask(taskId) {
        try {
            const success = window.storage.deleteTask(taskId);
            
            if (success) {
                this.renderTasks();
                this.updateStats();
                Utils.showToast('Task deleted successfully', 'success');
            } else {
                Utils.showToast('Failed to delete task', 'error');
            }
        } catch (error) {
            console.error('Error deleting task:', error);
            Utils.showToast('Error deleting task', 'error');
        }
    }
    
    /**
     * Close confirmation modal
     */
    closeConfirmModal() {
        this.elements.confirmModal.classList.remove('active');
        this.elements.confirmActionBtn.onclick = null;
    }
    
    /**
     * Update statistics in header
     */
    updateStats() {
        try {
            const stats = window.storage.getTaskStats();
            
            if (this.elements.totalTasks) {
                this.elements.totalTasks.textContent = stats.total;
            }
            if (this.elements.completedTasks) {
                this.elements.completedTasks.textContent = stats.completed;
            }
            if (this.elements.pendingTasks) {
                this.elements.pendingTasks.textContent = stats.pending;
            }

            // Dispatch event for profile page
            const statsUpdateEvent = new CustomEvent('statsUpdated', {
                detail: { stats }
            });
            window.dispatchEvent(statsUpdateEvent);
            
        } catch (error) {
            console.error('Error updating stats:', error);
        }
    }
    
    /**
     * Export tasks data
     */
    exportTasks() {
        try {
            const data = window.storage.exportData();
            const blob = new Blob([JSON.stringify(data, null, 2)], { 
                type: 'application/json' 
            });
            
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `taskflow-backup-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            Utils.showToast('Tasks exported successfully', 'success');
            
        } catch (error) {
            console.error('Error exporting tasks:', error);
            Utils.showToast('Error exporting tasks', 'error');
        }
    }
    
    /**
     * Import tasks data
     * @param {File} file - JSON file to import
     */
    importTasks(file) {
        try {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    const success = window.storage.importData(data);
                    
                    if (success) {
                        this.renderTasks();
                        this.updateStats();
                        Utils.showToast('Tasks imported successfully', 'success');
                    } else {
                        Utils.showToast('Failed to import tasks', 'error');
                    }
                } catch (error) {
                    console.error('Error parsing import file:', error);
                    Utils.showToast('Invalid file format', 'error');
                }
            };
            
            reader.readAsText(file);
            
        } catch (error) {
            console.error('Error importing tasks:', error);
            Utils.showToast('Error importing tasks', 'error');
        }
    }

    /**
     * Settings related methods
     */
    openSettings() {
        const settingsModal = document.getElementById('settingsModal');
        settingsModal.classList.add('active');
        
        // Set active theme option
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const themeOptions = document.querySelectorAll('.theme-option');
        themeOptions.forEach(option => {
            option.classList.toggle('active', option.dataset.theme === currentTheme);
        });
    }

    closeSettings() {
        const settingsModal = document.getElementById('settingsModal');
        settingsModal.classList.remove('active');
    }
}

// Initialize application
const app = new TaskFlowApp();

// Make app globally available
window.app = app;

// Initialize theme functionality
document.addEventListener('DOMContentLoaded', () => {
    // Theme Option Click Handlers
    document.querySelectorAll('.theme-option').forEach(option => {
        option.addEventListener('click', () => {
            const theme = option.dataset.theme;
            
            if (theme === 'system') {
                localStorage.removeItem('theme');
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                setTheme(prefersDark ? 'dark' : 'light');
            } else {
                setTheme(theme);
            }
            
            // Update active state
            document.querySelectorAll('.theme-option').forEach(opt => {
                opt.classList.toggle('active', opt === option);
            });
        });
    });

    // FAB Menu Functionality
    const fabButton = document.getElementById('fabButton');
    const fabMenu = document.getElementById('fabMenu');

    if (fabButton && fabMenu) {
        fabButton.addEventListener('click', () => {
            fabMenu.classList.toggle('active');
        });

        // Close FAB menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!fabButton.contains(e.target) && !fabMenu.contains(e.target)) {
                fabMenu.classList.remove('active');
            }
        });
    }

    // Close settings modal when clicking outside
    const settingsModal = document.getElementById('settingsModal');
    if (settingsModal) {
        settingsModal.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-overlay')) {
                app.closeSettings();
            }
        });
    }
});
