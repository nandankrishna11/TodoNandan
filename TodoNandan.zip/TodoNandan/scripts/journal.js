/**
 * Journal Manager Class
 * Handles all journal-related functionality including entries management and security
 */
class JournalManager {
    constructor() {
        // Initialize if DOM is ready
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            this.init();
        } else {
            document.addEventListener('DOMContentLoaded', () => this.init());
        }
    }

    /**
     * Initialize the journal manager
     */
    init() {
        this.isLocked = this.getIsLocked();
        this.setupEventListeners();
        this.checkLockStatus();
    }

    /**
     * Set up event listeners
     */
    setupEventListeners() {
        // Lock/Unlock button
        const lockBtn = document.getElementById('lockJournalBtn');
        if (lockBtn) {
            lockBtn.addEventListener('click', () => this.toggleLock());
        }

        // Unlock button in password prompt
        const unlockBtn = document.getElementById('unlockBtn');
        if (unlockBtn) {
            unlockBtn.addEventListener('click', () => this.attemptUnlock());
        }

        // Password input enter key
        const passwordInput = document.getElementById('journalPassword');
        if (passwordInput) {
            passwordInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.attemptUnlock();
                }
            });
        }
    }

    /**
     * Check if journal is locked and show appropriate view
     */
    checkLockStatus() {
        const journalActions = document.getElementById('journalActions');
        const passwordPrompt = document.getElementById('passwordPrompt');
        const lockBtn = document.getElementById('lockJournalBtn');

        if (this.isLocked) {
            journalActions.style.display = 'none';
            passwordPrompt.style.display = 'flex';
            lockBtn.innerHTML = '<i class="fas fa-lock"></i><span>Unlock Journal</span>';
        } else {
            journalActions.style.display = 'grid';
            passwordPrompt.style.display = 'none';
            lockBtn.innerHTML = '<i class="fas fa-lock-open"></i><span>Lock Journal</span>';
        }
    }

    /**
     * Toggle journal lock status
     */
    toggleLock() {
        if (this.isLocked) {
            // Show password prompt
            document.getElementById('passwordPrompt').style.display = 'flex';
        } else {
            // Prompt for new password
            const newPassword = prompt('Enter a password to lock your journal:');
            if (newPassword) {
                this.setPassword(newPassword);
                this.isLocked = true;
                this.saveIsLocked(true);
                this.checkLockStatus();
                Utils.showToast('Journal locked successfully', 'success');
            }
        }
    }

    /**
     * Attempt to unlock the journal
     */
    attemptUnlock() {
        const passwordInput = document.getElementById('journalPassword');
        const password = passwordInput.value;

        if (this.verifyPassword(password)) {
            this.isLocked = false;
            this.saveIsLocked(false);
            this.checkLockStatus();
            passwordInput.value = '';
            Utils.showToast('Journal unlocked successfully', 'success');
        } else {
            Utils.showToast('Incorrect password', 'error');
            passwordInput.value = '';
        }
    }

    /**
     * Create a new journal entry
     */
    createNewEntry() {
        if (this.isLocked) return;

        const journalActions = document.getElementById('journalActions');
        const journalEditor = document.getElementById('journalEditor');
        const entryDate = document.getElementById('entryDate');
        
        // Hide actions and show editor
        journalActions.style.display = 'none';
        journalEditor.style.display = 'block';
        
        // Set current date
        const now = new Date();
        entryDate.textContent = now.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        // Focus title input
        document.getElementById('entryTitle').focus();
    }

    /**
     * Save the current journal entry
     */
    saveEntry() {
        const title = document.getElementById('entryTitle').value.trim();
        const content = document.getElementById('entryContent').innerHTML.trim();
        
        if (!title || !content) {
            Utils.showToast('Please enter both title and content', 'warning');
            return;
        }
        
        const entry = {
            id: Date.now(),
            title,
            content,
            date: new Date().toISOString(),
            lastModified: new Date().toISOString()
        };
        
        // Save entry
        const entries = this.getEntries();
        entries.push(entry);
        this.saveEntries(entries);
        
        // Return to main view
        this.cancelEdit();
        Utils.showToast('Journal entry saved successfully', 'success');
    }

    /**
     * Cancel editing and return to main view
     */
    cancelEdit() {
        document.getElementById('journalActions').style.display = 'grid';
        document.getElementById('journalEditor').style.display = 'none';
        document.getElementById('entriesList').style.display = 'none';
        
        // Clear form
        document.getElementById('entryTitle').value = '';
        document.getElementById('entryContent').innerHTML = '';
    }

    /**
     * View all journal entries
     */
    viewEntries() {
        if (this.isLocked) return;

        const entries = this.getEntries();
        const entriesContainer = document.getElementById('entriesContainer');
        const entriesList = document.getElementById('entriesList');
        const journalActions = document.getElementById('journalActions');
        
        // Hide actions and show entries list
        journalActions.style.display = 'none';
        entriesList.style.display = 'block';
        
        // Clear and populate entries container
        entriesContainer.innerHTML = '';
        
        if (entries.length === 0) {
            entriesContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-book-open"></i>
                    <h3>No Entries Yet</h3>
                    <p>Start writing your first journal entry</p>
                    <button class="btn btn-primary" onclick="journal.createNewEntry()">
                        <i class="fas fa-pen"></i>
                        Create Entry
                    </button>
                </div>
            `;
            return;
        }
        
        // Sort entries by date (newest first)
        entries.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        // Create entry cards
        entries.forEach(entry => {
            const card = this.createEntryCard(entry);
            entriesContainer.appendChild(card);
        });
    }

    /**
     * Create an entry card element
     */
    createEntryCard(entry) {
        const div = document.createElement('div');
        div.className = 'entry-card';
        div.onclick = () => this.viewEntry(entry);
        
        const date = new Date(entry.date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        div.innerHTML = `
            <div class="entry-card-header">
                <h3 class="entry-card-title">${entry.title}</h3>
                <span class="entry-card-date">${date}</span>
            </div>
            <div class="entry-card-preview">${this.stripHtml(entry.content)}</div>
        `;
        
        return div;
    }

    /**
     * View a specific entry
     */
    viewEntry(entry) {
        const journalEditor = document.getElementById('journalEditor');
        const entriesList = document.getElementById('entriesList');
        
        // Hide entries list and show editor
        entriesList.style.display = 'none';
        journalEditor.style.display = 'block';
        
        // Populate editor
        document.getElementById('entryTitle').value = entry.title;
        document.getElementById('entryContent').innerHTML = entry.content;
        document.getElementById('entryDate').textContent = new Date(entry.date).toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }

    /**
     * Close entries list and return to main view
     */
    closeEntriesList() {
        document.getElementById('journalActions').style.display = 'grid';
        document.getElementById('entriesList').style.display = 'none';
    }

    /**
     * Strip HTML tags from text
     */
    stripHtml(html) {
        const tmp = document.createElement('div');
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || '';
    }

    /**
     * Storage Methods
     */
    getEntries() {
        try {
            const entries = localStorage.getItem('journalEntries');
            return entries ? JSON.parse(entries) : [];
        } catch (error) {
            console.error('Error getting entries:', error);
            return [];
        }
    }

    saveEntries(entries) {
        try {
            localStorage.setItem('journalEntries', JSON.stringify(entries));
        } catch (error) {
            console.error('Error saving entries:', error);
            Utils.showToast('Error saving entry', 'error');
        }
    }

    getIsLocked() {
        return localStorage.getItem('journalLocked') === 'true';
    }

    saveIsLocked(isLocked) {
        localStorage.setItem('journalLocked', isLocked);
    }

    setPassword(password) {
        // In a real app, you'd want to hash the password
        localStorage.setItem('journalPassword', password);
    }

    verifyPassword(password) {
        // In a real app, you'd want to compare hashed passwords
        return localStorage.getItem('journalPassword') === password;
    }

    /**
     * Open journal settings
     */
    openSettings() {
        if (this.isLocked) return;
        
        // TODO: Implement settings modal with theme options, font preferences, etc.
        Utils.showToast('Settings coming soon!', 'info');
    }
}

// Initialize journal manager
const journal = new JournalManager(); 