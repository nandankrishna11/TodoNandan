// Banner Manager
const BannerManager = {
    CONFIG: {
        maxWidth: 1200,
        maxHeight: 120, // Reduced height to match header
        minWidth: 800,
        minHeight: 80,
        aspectRatio: 10/1, // Wide but not too tall
        maxSize: 5 * 1024 * 1024 // 5MB
    },

    cropper: null,
    originalFile: null,

    init() {
        // Initialize banner elements
        const bannerInput = document.getElementById('bannerInput');
        const headerBanner = document.getElementById('headerBanner');

        if (bannerInput && headerBanner) {
            // Store default banner source
            headerBanner.dataset.defaultSrc = headerBanner.src;

            // Load saved banner if exists
            this.loadSavedBanner();

            // Set up event listeners
            this.setupEventListeners();
        }
    },

    setupEventListeners() {
        const bannerInput = document.getElementById('bannerInput');
        if (!bannerInput) return;

        bannerInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                this.originalFile = file;
                this.validateAndShowCropper(file);
            }
        });

        // Handle escape key to close modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && document.getElementById('cropperModal')) {
                this.closeCropperModal();
            }
        });
    },

    validateAndShowCropper(file) {
        // Check file size
        if (file.size > this.CONFIG.maxSize) {
            Utils.showToast(`File size should be less than ${this.CONFIG.maxSize / (1024 * 1024)}MB`, 'error');
            return;
        }

        // Check file type
        if (!file.type.startsWith('image/')) {
            Utils.showToast('Please upload an image file', 'error');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            this.showCropperModal(e.target.result);
        };
        reader.readAsDataURL(file);
    },

    showCropperModal(imageData) {
        // Remove any existing cropper modal
        this.closeCropperModal();

        // Create modal HTML
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'cropperModal';
        
        modal.innerHTML = `
            <div class="modal-container">
                <div class="modal-header">
                    <h3>Adjust Banner Image</h3>
                    <button class="modal-close" onclick="BannerManager.closeCropperModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="cropper-wrapper" style="max-height: 70vh; overflow: hidden;">
                        <img id="cropperImage" src="${imageData}" style="max-width: 100%;">
                    </div>
                    <div class="cropper-controls">
                        <button class="btn btn-secondary" onclick="BannerManager.rotateImage(-90)">
                            <i class="fas fa-undo"></i> Rotate Left
                        </button>
                        <button class="btn btn-secondary" onclick="BannerManager.rotateImage(90)">
                            <i class="fas fa-redo"></i> Rotate Right
                        </button>
                        <button class="btn btn-secondary" onclick="BannerManager.resetCropper()">
                            <i class="fas fa-sync"></i> Reset
                        </button>
                        <button class="btn btn-primary" onclick="BannerManager.cropImage()">
                            <i class="fas fa-check"></i> Apply Changes
                        </button>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Initialize cropper
        const image = document.getElementById('cropperImage');
        if (!image) {
            console.error('Cropper image element not found');
            return;
        }

        // Wait for image to load before initializing cropper
        image.onload = () => {
            try {
                this.cropper = new Cropper(image, {
                    aspectRatio: this.CONFIG.aspectRatio,
                    viewMode: 2,
                    guides: true,
                    autoCropArea: 0.8,
                    responsive: true,
                    restore: false,
                    center: true,
                    highlight: false,
                    cropBoxMovable: true,
                    cropBoxResizable: true,
                    toggleDragModeOnDblclick: false,
                    minCropBoxWidth: this.CONFIG.minWidth,
                    minCropBoxHeight: this.CONFIG.minHeight,
                    ready: () => {
                        console.log('Cropper initialized');
                        const containerData = this.cropper.getContainerData();
                        const cropBoxWidth = Math.min(containerData.width, this.CONFIG.maxWidth);
                        const cropBoxHeight = cropBoxWidth / this.CONFIG.aspectRatio;
                        
                        this.cropper.setCropBoxData({
                            width: cropBoxWidth,
                            height: cropBoxHeight,
                            left: (containerData.width - cropBoxWidth) / 2,
                            top: (containerData.height - cropBoxHeight) / 2
                        });
                    }
                });
            } catch (error) {
                console.error('Error initializing cropper:', error);
                Utils.showToast('Error initializing image editor', 'error');
            }
        };

        // Make modal draggable
        const modalContainer = modal.querySelector('.modal-container');
        this.makeModalDraggable(modalContainer);
    },

    makeModalDraggable(element) {
        let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        const header = element.querySelector('.modal-header');
        
        header.style.cursor = 'move';
        header.onmousedown = dragMouseDown;

        function dragMouseDown(e) {
            e.preventDefault();
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e.preventDefault();
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            element.style.top = (element.offsetTop - pos2) + "px";
            element.style.left = (element.offsetLeft - pos1) + "px";
        }

        function closeDragElement() {
            document.onmouseup = null;
            document.onmousemove = null;
        }
    },

    rotateImage(degree) {
        if (this.cropper) {
            try {
                this.cropper.rotate(degree);
            } catch (error) {
                console.error('Error rotating image:', error);
            }
        }
    },

    resetCropper() {
        if (this.cropper) {
            try {
                this.cropper.reset();
                console.log('Cropper reset');
            } catch (error) {
                console.error('Error resetting cropper:', error);
            }
        }
    },

    async cropImage() {
        if (!this.cropper) {
            console.error('Cropper not initialized');
            return;
        }

        try {
            // Get cropped canvas
            const canvas = await this.cropper.getCroppedCanvas({
                width: this.CONFIG.maxWidth,
                height: this.CONFIG.maxHeight,
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high',
            });

            if (!canvas) {
                throw new Error('Failed to create canvas');
            }

            // Convert to data URL
            const croppedImage = canvas.toDataURL('image/jpeg', 0.95);
            
            // Update banner first
            await this.updateBanner(croppedImage);
            
            // Show success message
            Utils.showToast('Banner updated successfully', 'success');
            
            // Close cropper modal
            this.closeCropperModal();
        } catch (error) {
            console.error('Error cropping image:', error);
            Utils.showToast('Error processing image', 'error');
        }
    },

    closeCropperModal() {
        if (this.cropper) {
            try {
                this.cropper.destroy();
            } catch (error) {
                console.error('Error destroying cropper:', error);
            }
            this.cropper = null;
        }
        
        const modal = document.getElementById('cropperModal');
        if (modal) {
            modal.remove();
        }
        
        // Clear the file input
        const bannerInput = document.getElementById('bannerInput');
        if (bannerInput) {
            bannerInput.value = '';
        }
    },

    async updateBanner(dataUrl) {
        const headerBanner = document.getElementById('headerBanner');
        if (!headerBanner) return;

        try {
            // Save first to ensure it's stored
            await this.saveBanner(dataUrl);
            
            // Then update the display
            headerBanner.src = dataUrl;
        } catch (error) {
            console.error('Error updating banner:', error);
            Utils.showToast('Error saving banner', 'error');
        }
    },

    async saveBanner(dataUrl) {
        try {
            localStorage.setItem('taskflow_banner', dataUrl);
            console.log('Banner saved successfully');
        } catch (error) {
            console.error('Error saving banner:', error);
            if (error.name === 'QuotaExceededError') {
                await this.saveCompressedBanner(dataUrl);
            } else {
                throw error;
            }
        }
    },

    async saveCompressedBanner(dataUrl) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                try {
                    const canvas = document.createElement('canvas');
                    canvas.width = this.CONFIG.maxWidth;
                    canvas.height = this.CONFIG.maxHeight;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    
                    // Save with lower quality
                    const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);
                    localStorage.setItem('taskflow_banner', compressedDataUrl);
                    console.log('Compressed banner saved successfully');
                    resolve();
                } catch (error) {
                    console.error('Error saving compressed banner:', error);
                    reject(error);
                }
            };
            img.onerror = reject;
            img.src = dataUrl;
        });
    },

    loadSavedBanner() {
        try {
            const savedBanner = localStorage.getItem('taskflow_banner');
            const headerBanner = document.getElementById('headerBanner');
            
            if (savedBanner && headerBanner) {
                headerBanner.src = savedBanner;
            }
        } catch (error) {
            console.error('Error loading banner:', error);
        }
    }
};

// Initialize banner manager
document.addEventListener('DOMContentLoaded', () => {
    BannerManager.init();
}); 