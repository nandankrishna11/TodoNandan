class FocusTimer {
    constructor() {
        this.isRunning = false;
        this.startTime = 0;
        this.elapsedTime = 0;
        this.timerInterval = null;
        this.soundEnabled = false;

        // Initialize if DOM is ready
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            this.init();
        } else {
            document.addEventListener('DOMContentLoaded', () => this.init());
        }
    }

    init() {
        this.cacheElements();
        this.setupEventListeners();
        this.loadSoundPreference();
    }

    cacheElements() {
        this.elements = {
            timerDisplay: document.getElementById('timerDisplay'),
            startBtn: document.getElementById('startBtn'),
            stopBtn: document.getElementById('stopBtn'),
            soundToggle: document.getElementById('soundToggle'),
            tickSound: document.getElementById('tickSound')
        };
    }

    setupEventListeners() {
        // Timer controls
        this.elements.startBtn.addEventListener('click', () => this.startTimer());
        this.elements.stopBtn.addEventListener('click', () => this.stopTimer());

        // Sound toggle
        this.elements.soundToggle.addEventListener('change', (e) => {
            this.soundEnabled = e.target.checked;
            localStorage.setItem('focusTimerSound', this.soundEnabled);
            this.toggleTickSound();
        });

        // Fullscreen toggle
        document.addEventListener('dblclick', () => this.toggleFullscreen());

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                e.preventDefault();
                if (this.isRunning) {
                    this.stopTimer();
                } else {
                    this.startTimer();
                }
            } else if (e.code === 'Escape' && document.fullscreenElement) {
                document.exitFullscreen();
            }
        });
    }

    startTimer() {
        if (!this.isRunning) {
            this.isRunning = true;
            this.startTime = Date.now() - this.elapsedTime;
            this.timerInterval = setInterval(() => this.updateTimer(), 1000);
            
            // Update button states
            this.elements.startBtn.disabled = true;
            this.elements.stopBtn.disabled = false;

            // Start tick sound if enabled
            this.toggleTickSound();

            // Update button text
            this.elements.startBtn.innerHTML = '<i class="fas fa-play"></i><span>Resume</span>';
        }
    }

    stopTimer() {
        if (this.isRunning) {
            this.isRunning = false;
            clearInterval(this.timerInterval);
            
            // Update button states
            this.elements.startBtn.disabled = false;
            this.elements.stopBtn.disabled = true;

            // Stop tick sound
            this.elements.tickSound.pause();
        }
    }

    updateTimer() {
        this.elapsedTime = Date.now() - this.startTime;
        this.elements.timerDisplay.textContent = this.formatTime(this.elapsedTime);
    }

    formatTime(ms) {
        const seconds = Math.floor((ms / 1000) % 60);
        const minutes = Math.floor((ms / 1000 / 60) % 60);
        const hours = Math.floor(ms / 1000 / 60 / 60);

        return [hours, minutes, seconds]
            .map(num => num.toString().padStart(2, '0'))
            .join(':');
    }

    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                console.log(`Error attempting to enable fullscreen: ${err.message}`);
            });
        } else {
            document.exitFullscreen();
        }
    }

    toggleTickSound() {
        if (this.isRunning && this.soundEnabled) {
            this.elements.tickSound.play();
        } else {
            this.elements.tickSound.pause();
        }
    }

    loadSoundPreference() {
        const savedPreference = localStorage.getItem('focusTimerSound');
        if (savedPreference !== null) {
            this.soundEnabled = savedPreference === 'true';
            this.elements.soundToggle.checked = this.soundEnabled;
        }
    }
}

// Initialize focus timer
const focusTimer = new FocusTimer(); 