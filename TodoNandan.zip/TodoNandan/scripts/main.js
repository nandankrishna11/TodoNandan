// Header scroll effect
const headerBanner = document.querySelector('.header-banner');
const headerContent = document.querySelector('.header-content');
let lastScrollY = window.scrollY;

function handleScroll() {
    // Add scrolled class to banner when scrolling starts
    if (window.scrollY > 10) {
        headerBanner.classList.add('scrolled');
        headerContent.classList.add('scrolled');
    } else {
        headerBanner.classList.remove('scrolled');
        headerContent.classList.remove('scrolled');
    }
    lastScrollY = window.scrollY;
}

// Add scroll event listener
window.addEventListener('scroll', handleScroll);

// Initialize header state on page load
handleScroll(); 