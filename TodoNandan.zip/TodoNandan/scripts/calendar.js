class CalendarManager {
    constructor() {
        this.currentDate = new Date();
        this.selectedDate = null;
        this.dailyTasks = {};
        this.notifications = [];
        this.notificationCheckInterval = null;

        // Initialize if DOM is ready
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            this.init();
        } else {
            document.addEventListener('DOMContentLoaded', () => this.init());
        }
    }

    init() {
        this.cacheElements();
        this.setupEventListeners();
        this.renderCalendar();
        this.loadDailyTasks();
        this.startNotificationCheck();

        // Request notification permission
        if (Notification.permission !== 'granted') {
            Notification.requestPermission();
        }
    }

    cacheElements() {
        this.elements = {
            calendarGrid: document.getElementById('calendarGrid'),
            calendarTitle: document.getElementById('calendarTitle'),
            prevWeekBtn: document.getElementById('prevWeekBtn'),
            nextWeekBtn: document.getElementById('nextWeekBtn'),
            dailyPlanner: document.getElementById('dailyPlanner'),
            plannerTitle: document.getElementById('plannerTitle'),
            timeSlots: document.getElementById('timeSlots'),
            addTaskBtn: document.getElementById('addTaskBtn')
        };
    }

    setupEventListeners() {
        if (this.elements.prevWeekBtn) {
            this.elements.prevWeekBtn.addEventListener('click', () => this.navigateWeek(-1));
        }
        if (this.elements.nextWeekBtn) {
            this.elements.nextWeekBtn.addEventListener('click', () => this.navigateWeek(1));
        }
        if (this.elements.addTaskBtn) {
            this.elements.addTaskBtn.addEventListener('click', () => this.addNewTimeSlot());
        }
    }

    renderCalendar() {
        const startOfWeek = new Date(this.currentDate);
        startOfWeek.setDate(this.currentDate.getDate() - this.currentDate.getDay());

        // Update calendar title
        if (this.elements.calendarTitle) {
            const endOfWeek = new Date(startOfWeek);
            endOfWeek.setDate(startOfWeek.getDate() + 6);
            
            const formatDate = (date) => {
                return date.toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric'
                });
            };
            
            this.elements.calendarTitle.textContent = 
                `${formatDate(startOfWeek)} - ${formatDate(endOfWeek)}`;
        }

        // Clear existing calendar
        if (this.elements.calendarGrid) {
            this.elements.calendarGrid.innerHTML = '';

            // Generate days
            for (let i = 0; i < 7; i++) {
                const date = new Date(startOfWeek);
                date.setDate(startOfWeek.getDate() + i);
                
                const dayEl = this.createDayElement(date);
                this.elements.calendarGrid.appendChild(dayEl);
            }
        }
    }

    createDayElement(date) {
        const dayEl = document.createElement('div');
        dayEl.className = 'calendar-day';
        
        // Check if it's today
        const isToday = this.isToday(date);
        if (isToday) {
            dayEl.classList.add('today');
        }
        
        // Check if it's selected
        if (this.selectedDate && this.isSameDay(date, this.selectedDate)) {
            dayEl.classList.add('selected');
        }
        
        dayEl.innerHTML = `
            <div class="day-number">${date.getDate()}</div>
            <div class="day-name">${date.toLocaleDateString('en-US', { weekday: 'short' })}</div>
        `;
        
        dayEl.addEventListener('click', () => {
            if (isToday && this.selectedDate && this.isSameDay(date, this.selectedDate)) {
                // If clicking today's date again when it's selected, close the planner
                this.selectedDate = null;
                this.elements.dailyPlanner.classList.remove('active');
                dayEl.classList.remove('selected');
            } else {
                this.selectDate(date);
            }
        });
        
        return dayEl;
    }

    navigateWeek(direction) {
        this.currentDate.setDate(this.currentDate.getDate() + (direction * 7));
        this.renderCalendar();
    }

    selectDate(date) {
        this.selectedDate = date;
        this.renderCalendar();
        this.showDailyPlanner(date);
    }

    showDailyPlanner(date) {
        if (!this.elements.dailyPlanner || !this.elements.plannerTitle || !this.elements.timeSlots) {
            return;
        }

        // Update planner title
        this.elements.plannerTitle.textContent = date.toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric'
        });

        // Show planner
        this.elements.dailyPlanner.classList.add('active');

        // Render time slots
        this.renderTimeSlots(date);
    }

    renderTimeSlots(date) {
        this.elements.timeSlots.innerHTML = '';
        const dateKey = this.getDateKey(date);
        const tasks = this.dailyTasks[dateKey] || {};

        // Add "Add Task" button at the top
        const addTaskBtn = document.createElement('button');
        addTaskBtn.className = 'task-btn add-task-btn';
        addTaskBtn.innerHTML = '<i class="fas fa-plus"></i> Add New Task';
        addTaskBtn.addEventListener('click', () => this.addNewTimeSlot(date));
        this.elements.timeSlots.appendChild(addTaskBtn);

        // Sort tasks by time
        const sortedTimes = Object.keys(tasks).sort();
        
        // Render existing tasks
        sortedTimes.forEach(time => {
            this.createTimeSlot(date, time, tasks[time]);
        });
    }

    addNewTimeSlot(date) {
        const now = new Date();
        const defaultTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        this.createTimeSlot(date, defaultTime, { title: '', description: '', notified: false });
    }

    createTimeSlot(date, time, taskData) {
        const timeSlot = document.createElement('div');
        timeSlot.className = 'time-slot';
        
        const timeInput = document.createElement('input');
        timeInput.type = 'time';
        timeInput.className = 'time-input';
        timeInput.value = time;
        
        const taskInput = document.createElement('input');
        taskInput.type = 'text';
        taskInput.className = 'task-input';
        taskInput.placeholder = 'Add task...';
        taskInput.value = taskData.title || '';

        const actions = document.createElement('div');
        actions.className = 'task-actions';

        const saveBtn = document.createElement('button');
        saveBtn.className = 'task-btn save-btn';
        saveBtn.innerHTML = '<i class="fas fa-save"></i>';
        saveBtn.title = 'Save task';

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'task-btn delete-btn';
        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
        deleteBtn.title = 'Delete task';
        
        // Event listeners
        saveBtn.addEventListener('click', () => {
            this.saveTask(date, timeInput.value, {
                title: taskInput.value,
                description: '',
                notified: false
            });
            this.showNotification('Task Saved', 'Your task has been saved successfully');
            this.renderTimeSlots(date); // Re-render to sort by time
        });

        deleteBtn.addEventListener('click', () => {
            this.deleteTask(date, time);
            timeSlot.remove();
            this.showNotification('Task Deleted', 'Your task has been deleted');
        });
        
        actions.appendChild(saveBtn);
        actions.appendChild(deleteBtn);
        
        timeSlot.appendChild(timeInput);
        timeSlot.appendChild(taskInput);
        timeSlot.appendChild(actions);
        
        this.elements.timeSlots.appendChild(timeSlot);
    }

    getTimeValue(tasks, hour) {
        for (const timeStr in tasks) {
            const [hours] = timeStr.split(':').map(Number);
            if (hours === hour) return timeStr;
        }
        return `${hour.toString().padStart(2, '0')}:00`;
    }

    getTaskTitle(tasks, hour) {
        for (const timeStr in tasks) {
            const [hours] = timeStr.split(':').map(Number);
            if (hours === hour) return tasks[timeStr].title || '';
        }
        return '';
    }

    saveTask(date, time, taskData) {
        const dateKey = this.getDateKey(date);
        if (!this.dailyTasks[dateKey]) {
            this.dailyTasks[dateKey] = {};
        }
        this.dailyTasks[dateKey][time] = taskData;
        this.saveDailyTasks();
    }

    deleteTask(date, time) {
        const dateKey = this.getDateKey(date);
        if (this.dailyTasks[dateKey] && this.dailyTasks[dateKey][time]) {
            delete this.dailyTasks[dateKey][time];
            this.saveDailyTasks();
        }
    }

    loadDailyTasks() {
        const saved = localStorage.getItem('dailyTasks');
        if (saved) {
            this.dailyTasks = JSON.parse(saved);
        }
    }

    saveDailyTasks() {
        localStorage.setItem('dailyTasks', JSON.stringify(this.dailyTasks));
    }

    // Utility functions
    isToday(date) {
        const today = new Date();
        return this.isSameDay(date, today);
    }

    isSameDay(date1, date2) {
        return date1.getDate() === date2.getDate() &&
               date1.getMonth() === date2.getMonth() &&
               date1.getFullYear() === date2.getFullYear();
    }

    getDateKey(date) {
        return date.toISOString().split('T')[0];
    }

    formatTime(hour) {
        const period = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour > 12 ? hour - 12 : hour;
        return `${displayHour}:00 ${period}`;
    }

    startNotificationCheck() {
        // Check for due tasks every minute
        this.notificationCheckInterval = setInterval(() => {
            this.checkForDueTasks();
        }, 60000); // 60000ms = 1 minute
    }

    checkForDueTasks() {
        const now = new Date();
        const currentDateKey = this.getDateKey(now);
        const currentHour = now.getHours();
        const currentMinute = now.getMinutes();

        const tasks = this.dailyTasks[currentDateKey];
        if (!tasks) return;

        Object.entries(tasks).forEach(([timeStr, task]) => {
            if (!task || !task.title || task.notified) return;

            const [hours, minutes] = timeStr.split(':').map(Number);
            
            // Check if it's time for the notification
            if (hours === currentHour && minutes === currentMinute) {
                this.showNotification(task.title, task.description || 'Task due now');
                
                // Mark as notified
                tasks[timeStr].notified = true;
                this.saveDailyTasks();
            }
        });
    }

    showNotification(title, message) {
        // Browser notification
        if (Notification.permission === 'granted') {
            new Notification(title, {
                body: message,
                icon: '/images/favicon.ico'
            });
        }

        // In-app notification
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.innerHTML = `
            <i class="fas fa-bell notification-icon"></i>
            <div class="notification-content">
                <div class="notification-title">${title}</div>
                <div class="notification-message">${message}</div>
            </div>
            <button class="notification-close">
                <i class="fas fa-times"></i>
            </button>
        `;

        document.body.appendChild(notification);

        // Remove notification after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideIn 0.3s ease-out reverse';
            setTimeout(() => notification.remove(), 300);
        }, 5000);

        // Close button functionality
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });
    }

    // Clean up when the component is destroyed
    destroy() {
        if (this.notificationCheckInterval) {
            clearInterval(this.notificationCheckInterval);
        }
    }
}

// Initialize calendar manager
const calendar = new CalendarManager(); 